import os
os.system('xdg-open https://chat.whatsapp.com/K9ymoZ68ndJ9JoednF3If7')